#include "OC.h"

void OCinit(){
    DRV_OC0_Start(); //OC_ID_1
    DRV_OC1_Start(); //OC_ID_2
    DRV_OC2_Start(); //OC_ID_3
    OC1_control(BASEFRONT);
    OC2_control(CLAWCLOSE);
    OC4_control(ARMNOEXTEND);

}

void TMRInit() {
    DRV_TMR0_Start(); //Timer ID_2

}

void OC1_control(float value){
    int period=DRV_TMR0_PeriodValueGet();
    int val= (int)(value*period/20);
    PLIB_OC_PulseWidth16BitSet(OC_ID_1,val);
    //PORTAbits.RA3 = !PORTAbits.RA3;
}

void OC2_control(float value){
    int period=DRV_TMR0_PeriodValueGet();
    int val= (int)(value*period/20);
    PLIB_OC_PulseWidth16BitSet(OC_ID_2,val);
}

void OC3_control(float value){
    int period=DRV_TMR0_PeriodValueGet();
    int val= (int)(value*period/20);
    PLIB_OC_PulseWidth16BitSet(OC_ID_3,val);
}

void OC4_control(float value){
    int period=DRV_TMR0_PeriodValueGet();
    int val= (int)(value*period/20);
    PLIB_OC_PulseWidth16BitSet(OC_ID_4,val);
}
