#include "SWtimer.h"


void SWTimerInit(){
    SWTimer = xTimerCreate("Timer",SWTIMERTICKS,pdFALSE,0,SWTimerCallBack);
}

void SWTimerCallBack(TimerHandle_t SWTimer){
    //MessageStruct myMessage;
    //myMessage.Source = SoftwareTimer;
    //SendMessageToQueue(myMessage);
    
    
    
    
    
    
    
    
    
    
    
    
    

}

void SWTimerStart(){
    xTimerStart(SWTimer,0);
}

void Timer_GET(){
    GETTimer = xTimerCreate("GETtimers",pdMS_TO_TICKS(200),pdTRUE,0,CallBackGET);

}

void Timer_GET_Start(){
    xTimerStart(GETTimer,0);

}

void CallBackGET(TimerHandle_t GETTimer)
{
    UART_Rx_Message mess;
    mess.uartType = TX;
    mess.httpType = GET;
    mess.transName = 'A';
    sendToRXQueue(mess);
}