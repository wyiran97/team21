/* 
 * File:   arm_state.h
 * Author: Ge Zhang
 *
 * Created on June 23, 2019, 9:31 PM
 */


#ifndef ARM_STATE_H
#define	ARM_STATE_H

#ifdef	__cplusplus
extern "C" {
#endif
#include <FreeRtos.h>
#include <queue.h>
#include "QueueStruct.h"
#include "action_state.h"
#include "arm_Queue.h"

    
typedef enum {WaitingMessage, Running, SendMessage} ArmStatus;
void ArmState(ArmStatus *armS, MessageStruct armMessage);



#ifdef	__cplusplus
}
#endif

#endif	/* ARM_STATE_H */

