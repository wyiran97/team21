#include "arm_Queue.h"


void armQueue_Init(){
    armQueue = xQueueCreate(ARMQUEUELENGTH,sizeof(MessageStruct));
    if(armQueue==NULL)
    {
    }
}

MessageStruct RecieveFromQueue(){
    MessageStruct result;
    if(xQueueReceive(armQueue,&result,portMAX_DELAY)){
        return result;
    }
}

void SendMessageToQueue(MessageStruct armMessage){
    if(xQueueSendToBack(armQueue,&armMessage,portMAX_DELAY)==pdPASS){
        
    }
    else{
        
    }
}