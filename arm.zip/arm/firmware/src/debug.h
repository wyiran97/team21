/* ************************************************************************** */
/** 
  @Course
    Summer2019 ECE 4534
 
  @File Name
    debug.h

  @Edited
    team 21
 */
/* ************************************************************************** */
#ifndef _DEBUG_H_
#define _DEBUG_H_


#include "system/common/sys_module.h"
#include "system_config.h"
#include "system_definitions.h"


#define DLOC_RECEIVE_FROM_RXQUEUE_BEGIN 0x10
#define DLOC_RECEIVE_FROM_RXQUEUE_END 0x11
#define DLOC_SEND_FROM_RXISR_BEGIN 0x12
#define DLOC_SEND_FROM_RXISR_END 0x13
#define DLOC_SEND_TO_RXQUEUE_BEGIN 0x14
#define DLOC_SEND_TO_RXQUEUE_END 0x15

#define DLOC_RECEIVE_FROM_TXQUEUE_BEGIN 0x20
#define DLOC_RECEIVE_FROM_TXQUEUE_END 0x21
#define DLOC_SEND_TO_TXQUEUE_BEGIN 0x24
#define DLOC_SEND_TO_TXQUEUE_END 0x25
#define DLOC_SEND_TO_TX2QUEUE_BEGIN 0x26
#define DLOC_SEND_TO_TX2QUEUE_END 0x27

#define DLOC_RECEIVE_FROM_TESTQUEUE_BEGIN 0x30
#define DLOC_RECEIVE_FROM_TESTQUEUE_END 0x31
#define DLOC_SEND_TO_TESTQUEUE_BEGIN 0x32
#define DLOC_SEND_TO_TESTQUEUE_END 0x33

//timer
#define TIMER_START 0x50
#define TIMER_CALLBACK 0x51
#define TEST_TIMER_START 0x52
#define TEST_TIMER_CALLBACK 0x53

//ISR
#define TX_ISR_ENTER 0x40
#define RX_ISR_ENTER 0x41
#define ERROR_ISR 0x42
#define TX4_ISR_ENTER 0x43
#define RX4_ISR_ENTER 0x44
#define ERROR4_ISR 0x45
//-------------------------------------------------------------


//indicate send from ISR is correct


#define DLOC_ENTER_ISR 0x30
#define DLOC_LEAVE_ISR 0x31

//indicate the state machine is running correct
#define DLOC_STATE_STOP 0x41
#define DLOC_STATE_GOSTRAIGHT 0x42
#define DLOC_STATE_GOBACK 0x43
#define DLOC_STATE_TURNLEFT 0x44
#define DLOC_STATE_TURNRIGHT 0x45
#define DLOC_STATE_FINISHTURN 0x46
#define DLOC_STATE_ADJUST 0x47
#define DLOC_STATE_ERROR 0x48

//indicate some errors happen during send and receive message
#define STOP_NO_RECEIVE 0xe0
#define STOP_NO_SEND 0xe1
#define STOP_CREATE_ERROR 0xe2


#define ADJUST_TIMER_START 0x52
#define ADJUST_CALLBACK 0x53


void dbgOutputLoc(unsigned int outVal);
void stop(unsigned int outVal);
/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif


    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _DEBUG_H */

/* *****************************************************************************
 End of File
 */
