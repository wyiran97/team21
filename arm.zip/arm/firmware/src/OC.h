/* 
 * File:   OC.h
 * Author: Ge Zhang
 *
 * Created on June 19, 2019, 10:03 PM
 */

#include "peripheral/oc/plib_oc.h"
#include "system/common/sys_module.h"
#include "system_config.h"
#include "system_definitions.h"
#include <FreeRtos.h>
#include "timers.h"
#include "QueueStruct.h"

#ifndef OC_H
#define	OC_H

#ifdef	__cplusplus
extern "C" {
#endif
#define BASEFRONT 1.1
#define BASERTURN 0.6
#define CLAWCLOSE 0.9
#define ARMNOEXTEND 0.5
void OCinit();
void TMRInit();

#ifdef	__cplusplus
}
#endif

#endif	/* OC_H */

