/*******************************************************************************
 System Interrupts File

  File Name:
    system_interrupt.c

  Summary:
    Raw ISR definitions.

  Description:
    This file contains a definitions of the raw ISRs required to support the
    interrupt sub-system.

  Summary:
    This file contains source code for the interrupt vector functions in the
    system.

  Description:
    This file contains source code for the interrupt vector functions in the
    system.  It implements the system and part specific vector "stub" functions
    from which the individual "Tasks" functions are called for any modules
    executing interrupt-driven in the MPLAB Harmony system.

  Remarks:
    This file requires access to the systemObjects global data structure that
    contains the object handles to all MPLAB Harmony module objects executing
    interrupt-driven in the system.  These handles are passed into the individual
    module "Tasks" functions to identify the instance of the module to maintain.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2011-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "system/common/sys_common.h"
#include "uart_thread.h"
#include "app.h"
#include "appt.h"
//#include "test_thread.h"
#include "debug.h"
#include "UART_queue.h"
#include "system_definitions.h"

// *****************************************************************************
// *****************************************************************************
// Section: System Interrupt Vector Functions
// *****************************************************************************
// *****************************************************************************

void IntHandlerDrvUsartInstance0(void)
{
    if(SYS_INT_SourceStatusGet(INT_SOURCE_USART_1_TRANSMIT) && PLIB_INT_SourceIsEnabled( INT_ID_0, INT_SOURCE_USART_1_TRANSMIT ))
    {
        dbgOutputLoc(0x01);
        BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
        requestTransmission();
    }
    if(SYS_INT_SourceStatusGet(INT_SOURCE_USART_1_RECEIVE) )
    {
        dbgOutputLoc(0x10);
        BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
        UART_Rx_Message msg; 
        msg.uartType = RX;
        msg.rx = PLIB_USART_ReceiverByteReceive(USART_ID_1);
        SendToRXQueueFromISR(msg, &pxHigherPriorityTaskWoken);
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_1_RECEIVE);
        portEND_SWITCHING_ISR(&pxHigherPriorityTaskWoken); 
    }
    if(SYS_INT_SourceStatusGet(INT_SOURCE_USART_1_ERROR) )
    {
        dbgOutputLoc(0x11);
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_1_ERROR);
    }
}
 
 






















 

void IntHandlerDrvUsartInstance1(void)
{
    if(SYS_INT_SourceStatusGet(INT_SOURCE_USART_4_TRANSMIT) && PLIB_INT_SourceIsEnabled( INT_ID_0, INT_SOURCE_USART_4_TRANSMIT ))
    {
        //dbgOutputLoc(TX4_ISR_ENTER);
       // BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
        //uint8_t str;
        // if(xQueuePeekFromISR(UART2_Tx_Queue, &str) == pdPASS  ) {
        //    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
        //    xQueueReceiveFromISR(UART2_Tx_Queue, &str, &pxHigherPriorityTaskWoken); 
        //    PLIB_USART_TransmitterByteSend(USART_ID_4, 'a');
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_4_TRANSMIT);
         //   portEND_SWITCHING_ISR(&pxHigherPriorityTaskWoken); 
       // } 
        
      //  else{
       //     PLIB_INT_SourceDisable(INT_ID_0, INT_SOURCE_USART_4_TRANSMIT ); // this means tx queue was empty
         //   PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_4_TRANSMIT);
       // }
    }
    if(SYS_INT_SourceStatusGet(INT_SOURCE_USART_4_RECEIVE) )
    {
        //dbgOutputLoc(RX4_ISR_ENTER);
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_4_RECEIVE);
    }
    if(SYS_INT_SourceStatusGet(INT_SOURCE_USART_4_ERROR) )
    {
        //dbgOutputLoc(ERROR4_ISR);
        PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_4_ERROR);
    }
}
 
 
 

 
 
void IntHandlerDrvTmrInstance0(void)
{
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_2);
}
void IntHandlerDrvTmrInstance1(void)
{
    PLIB_INT_SourceFlagClear(INT_ID_0,INT_SOURCE_TIMER_4);
}
 
 

 
 
 
/*******************************************************************************
 End of File
*/
