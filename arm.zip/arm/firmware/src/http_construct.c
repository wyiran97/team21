/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#include "http.h"

int httpConstructor(UART_Rx_Message msg, char rxBuffer[],int *sequenceNum)
{
    if (msg.httpType == PUT)
    {
        return putConstructor(msg, rxBuffer, sequenceNum);
    }
    else if (msg.httpType == GET)
    {
        return getConstructor(msg, rxBuffer, sequenceNum);
    }
}

int statisticConstructor(int requestCount, int correct, int miss, char buffer[], int *sequenceNum)
{
    cJSON *root = cJSON_CreateObject();
    cJSON_AddItemToObject(root,"name", cJSON_CreateString("arm"));
    cJSON_AddItemToObject(root,"requetSent",cJSON_CreateNumber(requestCount));
    cJSON_AddItemToObject(root,"correctReceive",cJSON_CreateNumber(correct));
    cJSON_AddItemToObject(root,"missReply",cJSON_CreateNumber(miss));
    char *rootObj = cJSON_PrintUnformatted(root);
    *sequenceNum = *sequenceNum + 1;
    sprintf(buffer, "PUT /stat2/%d HTTP/1.1\r\nHost: 192.168.0.10:80\r\nContent-type: application/json\r\nContent-length:%d \r\n\r\n", *sequenceNum, strlen(rootObj));
    strcat(buffer, rootObj);
    vPortFree(rootObj);
    cJSON_Delete(root);
    return strlen(buffer);
}

int putConstructor(UART_Rx_Message msg, char buffer[], int *sequenceNum)
{
    cJSON *root = cJSON_CreateObject();
    if (msg.transName == 'A')
    {
        //cJSON_AddItemToObject(root, "TESTNAME", cJSON_CreateString("test")); //edit board2
        cJSON_AddItemToObject(root, "ARM_VALUE", cJSON_CreateNumber(msg.transVal));
    }
    char *rootObj = cJSON_PrintUnformatted(root);
    *sequenceNum = *sequenceNum + 1;
    sprintf(buffer, "PUT /arm/%d HTTP/1.1\r\nHost: 192.168.0.10:80\r\nContent-type: application/json\r\nContent-length:%d \r\n\r\n", *sequenceNum, strlen(rootObj));
    strcat(buffer, rootObj);
    vPortFree(rootObj);
    cJSON_Delete(root);
    return strlen(buffer);
}

int getConstructor(UART_Rx_Message msg, char buffer[], int *sequenceNum)
{
    strcpy(buffer, "GET /");
    char sequenceNumChar[MAX_SEQUENCE_NUM];
    if (msg.transName == 'A')
    {
        *sequenceNum = *sequenceNum + 1;
        sprintf(sequenceNumChar, "%d", *sequenceNum);
        strcat(buffer, "arm/");  //edit here board_two board_three
        strcat(buffer,sequenceNumChar);
    }
    strcat(buffer, " HTTP/1.1\r\nHost: 192.168.0.10:80\r\n\r\n");
    return strlen(buffer);
}
/* *****************************************************************************
 End of File
 */

