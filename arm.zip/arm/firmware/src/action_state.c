#include "action_state.h"




ArmStatus Base_right_turn(double *BaseChange){
    OC1_control(*BaseChange);
    SWTimerStart();
    //OC1_control(0.9);
    *BaseChange = *BaseChange - 0.03;
    if(*BaseChange <=BASERTURN){
        return SendMessage;
    }
    else{
        return Running;
    }
}

ArmStatus Claw_Open(double *Claw){
    OC3_control(*Claw);
    SWTimerStart();
    //OC1_control(0.9);
    *Claw = *Claw + 0.03;
    if(*Claw >=CLAWOPEN){
        return SendMessage;
    }
    else{
        return Running;
    }
}

ArmStatus Arm_Extend(double *Arm){
    OC2_control(*Arm);
    SWTimerStart();
    //OC1_control(0.9);
    *Arm = *Arm + 0.03;
    if(*Arm >=ARMEXTEND){
        return SendMessage;
    }
    else{
        return Running;
    }
}

ArmStatus MOVE_1(double *Base,double *Claw,double *Arm)//Base 90 degree right turn, Claw 
{
    SWTimerStart();
    OC1_control(*Base);
    OC2_control(*Claw);
    OC3_control(*Arm);
    if(*Claw<=CLAWOPEN && *Base>=BASEFRONT)
    {
        *Claw = *Claw + 0.03;
    }
    else if(*Base>=BASERTURN){
        *Base = *Base - 0.03;
    }
    else if(*Arm <=ARMEXTEND)
    {
        *Arm = *Arm + 0.03;
    }
    else if(*Claw>=1.0){
        *Claw = *Claw - 0.03;
    }
    if(*Base<=0.6 && *Arm>=1.1 && *Claw <= 1.0){
        return SendMessage;
    }
    return Running;
    
    
}

ArmStatus MOVE_2(double *Base,double *Claw,double *Arm)//Base 90 degree right turn, Claw 
{
    SWTimerStart();
    OC1_control(*Base);
    OC2_control(*Claw);
    OC3_control(*Arm);
    if(*Claw<=CLAWOPEN)
    {
        *Claw = *Claw + 0.03;
        return Running;
    }
    return SendMessage;
    
    
}

ArmStatus MOVE_3(double *Base,double *Claw,double *Arm)//Base 90 degree right turn, Claw 
{
    SWTimerStart();
    OC1_control(*Base);
    OC2_control(*Claw);
    OC3_control(*Arm);
    if(*Base<=BASEFRONT)
    {
        *Base = *Base + 0.03;
        return Running;
    }
    return SendMessage;
    
    
}

ArmStatus RunAction(Actions *action){
    static double Base = 1.1;
    static double Claw = 0.9;
    static double Arm = 0.5;
    ArmStatus temStatus;
    switch(*action){
        case(BASERT):
            temStatus =Base_right_turn(&Base);
            if(temStatus==SendMessage){
                *action = NONE;
            }
            return temStatus;
        case(ClawOP):
            temStatus= Claw_Open(&Claw);
            if(temStatus==SendMessage){
                *action = NONE;
            }
            return temStatus;
        case(ARMEX):
            temStatus = Arm_Extend(&Arm);
            if(temStatus==SendMessage){
                *action = NONE;
            }
            return temStatus;
        case(MOVE1):
            temStatus = MOVE_1(&Base,&Claw,&Arm);
            if(temStatus==SendMessage){
                *action = NONE;
            }
            return temStatus;
        case(MOVE2):
            temStatus = MOVE_2(&Base,&Claw,&Arm);
            if(temStatus==SendMessage){
                *action = NONE;
            }
            return temStatus;    
        case(MOVE3):
            temStatus = MOVE_3(&Base,&Claw,&Arm);
            if(temStatus==SendMessage){
                *action = NONE;
            }
            return temStatus;            
        case(NONE):
            return WaitingMessage;
    }
}