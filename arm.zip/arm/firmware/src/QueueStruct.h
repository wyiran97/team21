/* 
 * File:   QueueStruct.h
 * Author: Ge Zhang
 *
 * Created on June 28, 2019, 3:22 PM
 */

#ifndef QUEUESTRUCT_H
#define	QUEUESTRUCT_H

#ifdef	__cplusplus
extern "C" {
#endif

    
typedef enum {Server,SoftwareTimer} MessageSource;
typedef enum {NONE,BASERT,ClawOP,ARMEX,MOVE1,MOVE2,MOVE3,CHECKING} Actions;

typedef struct{
    MessageSource Source;
    Actions Action;
    
}  MessageStruct;


#ifdef	__cplusplus
}
#endif

#endif	/* QUEUESTRUCT_H */

