/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */
#include "UART_queue.h"
#include "debug.h"
void UARTQueue_Initialize()
{
    UART_Tx_Queue = xQueueCreate(QUEUE_SIZE,sizeof(UART_Tx_Message));
    dbgOutputLoc(0x74);
    UART_Rx_Queue = xQueueCreate(QUEUE_SIZE,sizeof(UART_Rx_Message));
}

UART_Rx_Message ReceiveFromRxQueue()
{
    UART_Rx_Message result;
    dbgOutputLoc(DLOC_RECEIVE_FROM_RXQUEUE_BEGIN);
    if (xQueueReceive(UART_Rx_Queue, &result, portMAX_DELAY))
    {
        dbgOutputLoc(DLOC_RECEIVE_FROM_RXQUEUE_END);
        return result;
    }
    else
    {
        stop(STOP_NO_RECEIVE);
    }
}

UART_Tx_Message ReceiveFromTxQueueISR(BaseType_t *pxHigherPriorityTaskWoken)
{
    UART_Tx_Message result;
    dbgOutputLoc(DLOC_RECEIVE_FROM_TXQUEUE_BEGIN);
    if (xQueueReceiveFromISR(UART_Tx_Queue, &result,  pxHigherPriorityTaskWoken))
    {
        dbgOutputLoc(DLOC_RECEIVE_FROM_TXQUEUE_END);
        return result;
    }
    else
    {
        stop(STOP_NO_RECEIVE);
    }
}

void SendToRXQueueFromISR(UART_Rx_Message msg, BaseType_t *pxHigherPriorityTaskWoken)
{
    dbgOutputLoc(DLOC_SEND_FROM_RXISR_BEGIN);
    if (xQueueSendToBackFromISR(UART_Rx_Queue, &msg, pxHigherPriorityTaskWoken) == pdPASS)
    {
        dbgOutputLoc(DLOC_SEND_FROM_RXISR_END);  //send successfully
    }
    else
    {
        stop(STOP_NO_SEND);
    }
}

void sendToRXQueue(UART_Rx_Message msg)
{
    dbgOutputLoc(DLOC_SEND_TO_RXQUEUE_BEGIN);
    if (xQueueSendToBack(UART_Rx_Queue, &msg, QUEUE_AVALIABLE_DELAY) == pdTRUE)
    {
        dbgOutputLoc(DLOC_SEND_TO_RXQUEUE_END);
    }
}

void sendToTXQueue(UART_Tx_Message msg)
{
    dbgOutputLoc(DLOC_SEND_TO_TXQUEUE_BEGIN);
    if (xQueueSendToBack(UART_Tx_Queue, &msg, QUEUE_AVALIABLE_DELAY) == pdTRUE)
    {
        dbgOutputLoc(DLOC_SEND_TO_TXQUEUE_END);
    }
}



void sendToUART2TXQueue(char *str)
{ 
    dbgOutputLoc(DLOC_SEND_TO_TX2QUEUE_BEGIN);
    int i;
    for (i = 0; i < strlen(str); i++)
    {
        if (xQueueSendToBack(UART2_Tx_Queue, (uint8_t)str[i], QUEUE_AVALIABLE_DELAY) == pdTRUE)
      {
          dbgOutputLoc(DLOC_SEND_TO_TX2QUEUE_END);
      }
    }
   
    
}
/* *****************************************************************************
 End of File
 */

