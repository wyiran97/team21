#include "arm_state.h"
#include "UART_queue.h"

void ArmState(ArmStatus *armS, MessageStruct armMessage){
    static Actions actions = NONE;
    UART_Rx_Message ms;
    switch(*armS){
        case(WaitingMessage):
            if(armMessage.Action!=NONE && armMessage.Action!=CHECKING){
                
                actions = armMessage.Action;
                *armS = RunAction(&actions);
            }
            else if(armMessage.Action=CHECKING)
            {
                *armS = SendMessage;
            }
            else if(actions!=NONE){
                *armS = Running;
            }
            break;

        case(Running):
            *armS = RunAction(&actions);
            
            break;
        case(SendMessage):
            ms.transName = 'A';
            ms.uartType = TX;
            ms.transVal = 1;
            ms.httpType = PUT;
            ms.rx = 0x00;
            sendToRXQueue(ms); 
            *armS= WaitingMessage;
            break;
             
    }
}
