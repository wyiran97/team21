/* 
 * File:   action_state.h
 * Author: Ge Zhang
 *
 * Created on June 28, 2019, 4:52 PM
 */

#ifndef ACTION_STATE_H
#define	ACTION_STATE_H

#ifdef	__cplusplus
extern "C" {
#endif
#include "OC.h"
#include "QueueStruct.h"
#include "arm_Queue.h"
#include "SWtimer.h"
#include "arm_state.h"

#define CLAWOPEN 1.5
#define BASERTURN 0.5
#define ARMEXTEND 1.1
#ifdef	__cplusplus
}
#endif

#endif	/* ACTION_STATE_H */

