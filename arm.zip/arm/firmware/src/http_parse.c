/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */
#include "http.h"
#include "QueueStruct.h"
#include "arm_Queue.h"

void httpParser(httpParseState_t *parseState, char rxData, int *correct, int *miss)
{
    static int position = 0;
    static char parseBuffer[MAX_SIZE_NUM+1];  //store parsing chars
    static int length = 0; //message length
    static int lengthPosition = 0; //content-length position 
    position = fillingParseBuffer(parseBuffer, rxData, position);
    
    switch (*parseState)
    {
        case INIT:
            if (getHttpHeader(parseBuffer, position))
            {
                *parseState = startRecieve;
                position = -1;
            }
            break;
        case startRecieve:
            if (getHttpHeader(parseBuffer, position))
            {
                position = -1;
            }
            else if (position == 7)
            {
                if (parseBuffer[5] == '2' && parseBuffer[6] == '0')     //200 201 is correct receive
                {
                    *parseState = getRecieve;
                    position = -1;
                }
                else //if not correct recieve, start again
                {
                    *parseState = INIT;
                }
            }
            break;
        case getRecieve:
            if (getHttpHeader(parseBuffer, position))
            {
                position = -1;
                *parseState = startRecieve;
            }
            else if (parseBuffer[position] == ' ' &&parseBuffer[position-1] == ':' &&
                    parseBuffer[position-2] == 'h' &&parseBuffer[position-3] == 't' &&parseBuffer[position-4] == 'g' &&parseBuffer[position-5] == 'n' &&
                    parseBuffer[position-6] == 'e' &&parseBuffer[position-7] == 'L' &&position > 16)
            {
                *parseState = lengthRecieve;
                lengthPosition = position + 1; //get the position of the content-length
            }
            break;
        case lengthRecieve:
            if (getHttpHeader(parseBuffer, position))
            {
                position = -1;
                *parseState = startRecieve;
            }
            else if (parseBuffer[position] == '\n' && parseBuffer[position - 1] == '\r' && parseBuffer[position-2] == '\n')
            {
                length = 0;
                int i;
                int j = 0;
                for (i = position - 4;i >= lengthPosition; i--)  //convert content-length to integer
                {
                    length = length + (int)(parseBuffer[i] - '0')*pow(10,j);  //adding ten digit and hundreds digit together
                    j++;
                }
                *parseState = bodyRecieve;
                position = -1;
            }
            break;
        case bodyRecieve:
            if (getHttpHeader(parseBuffer, position))
            {
                position = -1;
                *parseState = startRecieve;
            }
            else if (parseBuffer[position] == '}')
            {
                if (position == length - 1)
                {
                    char decodeBuffer[length];
                    int i;
                    for (i = 0; i < length; i++)
                    {
                        decodeBuffer[i] = parseBuffer[i];
                    }
                    decodeMessage(decodeBuffer, correct, miss); //parse json code
                }
                *parseState = INIT;
            }
            break;
        default:
            break;
    }
     
}

void decodeMessage(char decodeBuffer[], int *correct, int *miss)
{
    static char *name;
    static int curSequence = 0;
    cJSON *root = cJSON_Parse(decodeBuffer);
    if (root != NULL)
    {
        //cJSON *testName = cJSON_GetObjectItem(root, "TESTNAME");
        cJSON *testValue = cJSON_GetObjectItem(root, "ARM_VALUE");
        cJSON *sequence = cJSON_GetObjectItem(root, "seq");
        cJSON *from = cJSON_GetObjectItem(root, "name");
        if (from != NULL && testValue != NULL)
        {
            //name = testName->valuestring;
            MessageStruct msg;
            msg.Source = Server;
            if(testValue->valueint == 0){
                msg.Action = CHECKING;
                SendMessageToQueue(msg);
            }
            if(testValue->valueint == 1){
                msg.Action = NONE;
                SendMessageToQueue(msg);
            }
            
            if(testValue->valueint == 2)
            {
                msg.Action = MOVE1;
                SendMessageToQueue(msg);
            }
            if(testValue->valueint == 3)
            {
                msg.Action = MOVE2;
                SendMessageToQueue(msg);
            }
            if(testValue->valueint == 4)
            {
                msg.Action = MOVE3;
                SendMessageToQueue(msg);
            }
            
            char buffer[2];
            itoa(buffer,testValue->valueint, 10);
            PLIB_USART_TransmitterByteSend(USART_ID_4, buffer[0]);
            PLIB_USART_TransmitterByteSend(USART_ID_4, buffer[1]);
        }
        
        //check the sequence number
        if (sequence != NULL)
        {
            *correct = *correct + 1;
            curSequence++;
            int difference;
            difference = sequence->valueint - curSequence;
            if (difference >= 1)
            {
                *miss = *miss + difference;
            }
            curSequence = sequence->valueint + 1;
        }
    }
    cJSON_Delete(root);
}
int fillingParseBuffer(char buffer[], char rx, int position)
{
    int result;
    if (position == MAX_SIZE_NUM)
    {
        result = 0;
    }
    else
    {
        result = position + 1;
    }
    buffer[result] = rx;
    return result;
}

bool getHttpHeader(char buffer[], int position)
{
    if (position > 2) 
    {
        if (buffer[position] == 'P' && buffer[position-1] == 'T' && buffer[position-2] == 'T' && buffer[position-3] == 'H')
            return true;
    }
    else if (position == 2) 
    {
        if (buffer[2] == 'P' && buffer[1] == 'T' && buffer[0] == 'T' && buffer[MAX_SIZE_NUM] == 'H')
            return true;
    }
    else if (position == 1) 
    {
        if (buffer[1] == 'P' && buffer[0] == 'T' && buffer[MAX_SIZE_NUM] == 'T' && buffer[MAX_SIZE_NUM-1] == 'H')
            return true;
    }
    else{
        if (buffer[0] == 'P' && buffer[MAX_SIZE_NUM] == 'T' && buffer[MAX_SIZE_NUM-1] == 'T' && buffer[MAX_SIZE_NUM-2] == 'H')
            return true;
    }
    return false;
}


/* *****************************************************************************
 End of File
 */

