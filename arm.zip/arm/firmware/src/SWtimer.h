/* 
 * File:   SWtimer.h
 * Author: Ge Zhang
 *
 * Created on June 28, 2019, 6:11 PM
 */

#ifndef SWTIMER_H
#define	SWTIMER_H

#ifdef	__cplusplus
extern "C" {
#endif
#include "QueueStruct.h"
#include "OC.h"    
#include "arm_Queue.h"
#include <FreeRtos.h>
#include <queue.h>
#include "timers.h"
#include "arm_state.h"
#include "UART_queue.h"
#define SWTIMERTICKS pdMS_TO_TICKS(200)
    
TimerHandle_t SWTimer;
TimerHandle_t GETTimer;
void SWTimerCallBack(TimerHandle_t SWTimer);
void SWTimerInit();

void SWTimerStart();
void CallBackGET(TimerHandle_t GETTimer);
void Timer_GET();
void Timer_GET_Start();



#ifdef	__cplusplus
}
#endif

#endif	/* SWTIMER_H */

