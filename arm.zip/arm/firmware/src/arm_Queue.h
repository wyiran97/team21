/* 
 * File:   arm_Queue.h
 * Author: Ge Zhang
 *
 * Created on June 28, 2019, 3:56 PM
 */

#ifndef ARM_QUEUE_H
#define	ARM_QUEUE_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <FreeRTOS.h>
#include "queue.h"
#include "system_config.h"
#include "system_definitions.h"
#include "QueueStruct.h"
#include "action_state.h"
#include "arm_state.h"
    

#define ARMQUEUELENGTH 20

QueueHandle_t armQueue;
void armQueue_Init();
MessageStruct RecieveFromQueue();
void SendMessageToQueue(MessageStruct armMessage);


#ifdef	__cplusplus
}
#endif

#endif	/* ARM_QUEUE_H */

