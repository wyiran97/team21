/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#include "UART_state.h"
void uartStateMachine(httpParseState_t *parseState, UART_Rx_Message msg)
{
    static int requestCount = 0;
    static int correct = 0;
    static int miss = 0;
    static char requestBuffer[500] = {};
    static int sequenceNum = 0;
    int requestLength;
    UART_Tx_Message transMsg;
    switch (msg.uartType)
    {
        case TX:
            requestLength = httpConstructor(msg, requestBuffer,&sequenceNum);
            transMsg.txMessage = requestBuffer;
            transMsg.size = requestLength;
            sendToTXQueue(transMsg);
            requestCount++;
            SYS_INT_SourceEnable(INT_SOURCE_USART_1_TRANSMIT);
            break;
        case RX:
            httpParser(parseState, msg, &correct, &miss);
            break;
        case STATISTIC:
            requestLength = statisticConstructor(requestCount, correct, miss, requestBuffer, &sequenceNum);
            transMsg.txMessage = requestBuffer;
            transMsg.size = requestLength;
            sendToTXQueue(transMsg);
            SYS_INT_SourceEnable(INT_SOURCE_USART_1_TRANSMIT);
            break;
    }
}

void requestTransmission()
{
    BaseType_t pxHigherPriorityTaskWoken = pdFALSE;
    static bool lastMsgDone = true; //check if the last request is completed transmission
    static uint16_t index = 0;
    UART_Tx_Message txMsg;  //receive the request in tx queue
    UART_Tx_Message temp;  //check if the queue is empty or has some request
    
    
    switch(lastMsgDone)
    {
        case false:
            if (txMsg.size > index)
            {
                PLIB_USART_TransmitterByteSend(USART_ID_1, txMsg.txBuffer[index++]);
            }
            else //previous message is completed transmission
            {
                index = 0;
                lastMsgDone = true;
            }
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_1_TRANSMIT);
            break;
        case true:  //if previous char array is completed transmission, go to this state and receive next message from queue
            if (xQueuePeekFromISR(UART_Tx_Queue, &temp) == pdTRUE)
            {
                txMsg = ReceiveFromTxQueueISR(&pxHigherPriorityTaskWoken);
                strcpy(txMsg.txBuffer, txMsg.txMessage);
                PLIB_USART_TransmitterByteSend(USART_ID_1, txMsg.txBuffer[index++]);
                lastMsgDone = false;
            }
            else
            {
                PLIB_INT_SourceDisable(INT_ID_0, INT_SOURCE_USART_1_TRANSMIT);
            }
            PLIB_INT_SourceFlagClear(INT_ID_0, INT_SOURCE_USART_1_TRANSMIT);
            break;
        
    }
     
    
}
/* *****************************************************************************
 End of File
 */
