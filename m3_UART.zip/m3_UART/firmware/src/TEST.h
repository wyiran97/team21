/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _TEST_H    /* Guard against multiple inclusion */
#define _TEST_H
#include <stdio.h>
#include <FreeRTOS.h>
#include "queue.h"
#include "system_config.h"
#include "system_definitions.h"
#include <math.h>
#include "timers.h"
#include "debug.h"

#define TEST_QUEUE_SIZE 50
#define TEST_QUEUE_AVALIABLE_DELAY 0
#define TIME_MS 90
#define TIMER_ID 0
#define DELAY_TIME 0
QueueHandle_t testQueue;
typedef struct {
    int value;
    char *testName;
    int testFrom; // 1 is rx, 0 is timer sending
}testMessage;
void testQueue_Initialize();
testMessage ReceiveFromTestQueue();
void SendToTestQueue(testMessage msg);

TimerHandle_t testTimer;
void TestTimer_Initialize();
void testTimerCallBack(TimerHandle_t xTimer);

typedef enum {t1,t2,t3,t4,t5,t6,t7,t8,t9,t10} testState_t;
void testStateMachine(testState_t *testState, testMessage msg);
void sendTestMsgToUartThread(testState_t *testState);
/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif


  
    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
