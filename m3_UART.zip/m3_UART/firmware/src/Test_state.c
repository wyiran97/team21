/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#include "TEST.h"
#include "UART_queue.h"
#define FROM_RX 1
#define FROM_TIMER 0
void testStateMachine(testState_t *testState, testMessage msg)
{
    if (msg.testFrom == FROM_RX)
    {
        
        sendToUART2TXQueue(msg.testName);
       // SYS_INT_SourceEnable(INT_SOURCE_USART_4_TRANSMIT);
    }
    else if (msg.testFrom == FROM_TIMER)
    {
        sendTestMsgToUartThread(testState);
    }
}

void sendTestMsgToUartThread(testState_t *testState)
{
    UART_Rx_Message msg;
    switch(*testState)
    {
        case t1:
            msg.uartType = TX;
            msg.transVal = 11;
            msg.transName = 'T';
            msg.httpType = PUT;
            msg.rx = 0x00;
            sendToRXQueue(msg);
            *testState = t2;
            break;
        case t2:
            msg.uartType = TX;
            msg.transVal = 11;
            msg.transName = 'T';
            msg.httpType = GET;
            msg.rx = 0x00;
            sendToRXQueue(msg);
            *testState = t3;
            break;
        case t3:
            msg.uartType = TX;
            msg.transVal = 22;
            msg.transName = 'T';
            msg.httpType = PUT;
            msg.rx = 0x00;
            sendToRXQueue(msg);
            *testState = t4;
            break;
        case t4:
            msg.uartType = TX;
            msg.transVal = 22;
            msg.transName = 'T';
            msg.httpType = GET;
            msg.rx = 0x00;
            sendToRXQueue(msg);
            *testState = t5;
            break;
        case t5:
            msg.uartType = TX;
            msg.transVal = 33;
            msg.transName = 'T';
            msg.httpType = PUT;
            msg.rx = 0x00;
            sendToRXQueue(msg);
            *testState = t6;
            break;
        case t6:
            msg.uartType = TX;
            msg.transVal = 33;
            msg.transName = 'T';
            msg.httpType = GET;
            msg.rx = 0x00;
            sendToRXQueue(msg);
            *testState = t7;
            break;
        case t7:
            msg.uartType = TX;
            msg.transVal = 44;
            msg.transName = 'T';
            msg.httpType = PUT;
            msg.rx = 0x00;
            sendToRXQueue(msg);
            *testState = t8;
            break;
        case t8:
            msg.uartType = TX;
            msg.transVal = 44;
            msg.transName = 'T';
            msg.httpType = GET;
            msg.rx = 0x00;
            sendToRXQueue(msg);
            *testState = t9;
            break;
        case t9:
            msg.uartType = TX;
            msg.transVal = 55;
            msg.transName = 'T';
            msg.httpType = PUT;
            msg.rx = 0x00;
            sendToRXQueue(msg);
            *testState = t10;
            break;
        case t10:
            msg.uartType = TX;
            msg.transVal = 55;
            msg.transName = 'T';
            msg.httpType = GET;
            msg.rx = 0x00;
            sendToRXQueue(msg);
            *testState = t1;
            break;
    }
}
/* *****************************************************************************
 End of File
 */
