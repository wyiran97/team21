/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _UART_QUEUE_H    /* Guard against multiple inclusion */
#define _UART_QUEUE_H

#include <stdio.h>
#include <FreeRTOS.h>
#include "queue.h"
#include "system_config.h"
#include "system_definitions.h"
#include <math.h>
#define QUEUE_SIZE 100
#define QUEUE_AVALIABLE_DELAY 0
#define QUEUE_SIZE_2 275

QueueHandle_t UART_Tx_Queue;
QueueHandle_t UART_Rx_Queue;
QueueHandle_t UART2_Tx_Queue;

typedef enum {TX, RX, STATISTIC} UART_t;
typedef enum {PUT, GET} http_t;

typedef struct {
    UART_t uartType;
    char rx;
    http_t httpType;
    int transVal;
    char transName;
}UART_Rx_Message;

typedef struct {
    uint16_t size;
    char * txMessage;
    uint8_t txBuffer[275];
}UART_Tx_Message;

void UARTQueue_Initialize();
UART_Rx_Message ReceiveFromRxQueue();
UART_Tx_Message ReceiveFromTxQueueISR(BaseType_t *pxHigherPriorityTaskWoken);
void SendToRXQueueFromISR(UART_Rx_Message msg, BaseType_t *pxHigherPriorityTaskWoken);
void sendToRXQueue(UART_Rx_Message msg);
void sendToTXQueue(UART_Tx_Message msg);

void UART2Queue_Initialize();
void sendToUART2TXQueue(char *str);
/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif


    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
