/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#include "UART_timer.h"

void Timer_Initialize()
{
    uartTimer = xTimerCreate("stastisticTimer", pdMS_TO_TICKS(ONE_SECOND), pdTRUE ,(void*) TIMER_ID, TimerCallBack);
    //dbgOutputLoc(TIMER_START);
    xTimerStart(uartTimer, DELAY_TIME);
}

void TimerCallBack(TimerHandle_t xTimer)
{
    //dbgOutputLoc(TIMER_CALLBACK);
    UART_Rx_Message msg;
    msg.uartType = STATISTIC;
    msg.rx = 0x00;
    sendToRXQueue(msg);
}
/* *****************************************************************************
 End of File
 */
