/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */
#include "TEST.h"
#define FROM_TEST_TIMER 0
#define FROM_UART_RX 1

void testQueue_Initialize()
{
    testQueue = xQueueCreate(TEST_QUEUE_SIZE,sizeof(testMessage));
}

testMessage ReceiveFromTestQueue()
{
    testMessage result;
   // dbgOutputLoc(DLOC_RECEIVE_FROM_TESTQUEUE_BEGIN);
    if (xQueueReceive(testQueue, &result, portMAX_DELAY))
    {
        //dbgOutputLoc(DLOC_RECEIVE_FROM_TESTQUEUE_END);
        return result;
    }
    else
    {
        stop(STOP_NO_RECEIVE);
    }
}

void SendToTestQueue(testMessage msg)
{
    //dbgOutputLoc(DLOC_SEND_TO_TESTQUEUE_BEGIN);
    if (xQueueSendToBack(testQueue, &msg, TEST_QUEUE_AVALIABLE_DELAY) == pdTRUE)
    {
        //dbgOutputLoc(DLOC_SEND_TO_TESTQUEUE_END);
    }
}



void TestTimer_Initialize()
{
    testTimer = xTimerCreate("testTimer", pdMS_TO_TICKS(100), pdTRUE ,(void*) TIMER_ID, testTimerCallBack);
    //dbgOutputLoc(TEST_TIMER_START);
    xTimerStart(testTimer, DELAY_TIME);
}

void testTimerCallBack(TimerHandle_t xTimer)
{
   // dbgOutputLoc(TEST_TIMER_CALLBACK);
    testMessage msg;
    msg.testFrom = FROM_TEST_TIMER;
    SendToTestQueue(msg);
}
/* *****************************************************************************
 End of File
 */
