/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _HTTP_H    /* Guard against multiple inclusion */
#define _HTTP_H
#include "UART_queue.h"
#include "UART_state.h"
#include "cJSON.h"
#define MAX_SEQUENCE_NUM 6
#define MAX_SIZE_NUM 200
int httpConstructor(UART_Rx_Message msg, char rxBuffer[],int *sequenceNum);
int putConstructor(UART_Rx_Message msg, char buffer[], int *sequenceNum);
int getConstructor(UART_Rx_Message msg, char buffer[], int *sequenceNum);
int statisticConstructor(int requestCount, int correct, int miss, char buffer[], int *sequenceNum);
void httpParser(httpParseState_t *parseState, char rxData, int *correct, int *miss);
bool getHttpHeader(char buffer[], int position);
int fillingParseBuffer(char buffer[], char rx, int position);
void decodeMessage(char decodeBuffer[], int *correct, int *miss);
/* Provide C++ Compatibility */
#ifdef __cplusplus
extern "C" {
#endif

    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
