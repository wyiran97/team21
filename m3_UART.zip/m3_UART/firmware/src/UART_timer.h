/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _UART_TIMER_H    /* Guard against multiple inclusion */
#define _UART_TIMER_H
#include <FreeRTOS.h>
#include "timers.h"
#include "UART_queue.h"
#include "debug.h"

#define ONE_SECOND 1000
#define TIMER_ID 0
#define DELAY_TIME 0
TimerHandle_t uartTimer;
void Timer_Initialize();
void TimerCallBack(TimerHandle_t xTimer);


#ifdef __cplusplus
extern "C" {
#endif

    /* Provide C++ Compatibility */
#ifdef __cplusplus
}
#endif

#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
